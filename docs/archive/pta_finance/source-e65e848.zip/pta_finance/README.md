# pta_finance

[![CI](https://github.com/aberson/pta_finance/actions/workflows/ci.yml/badge.svg)](https://github.com/aberson/pta_finance/actions/workflows/ci.yml)
[![Python 3.12+](https://img.shields.io/badge/python-3.12%2B-blue)](pyproject.toml)
[![License: MIT](https://img.shields.io/badge/license-MIT-green)](LICENSE)

Keep PTA finances in order: **plan a budget, review reimbursements, and explain the numbers to
your board.** Also suited to booster clubs and small nonprofits.

- **Plan the budget.** Edit amounts in Google Sheets and check changes before saving.
- **Review reimbursements.** See each request, its status, and what needs to happen next.
- **Explain the numbers.** Track fundraising, spending, and progress against the budget.

Google Sheets holds the budget. A local Python tool prepares the reports, which open in your
browser.

![Reimbursement review showing totals, request statuses, and next actions for a fictional PTA](docs/screenshots/reimbursement-queue.png)

*The real review report with fictional names, amounts, and decisions. All examples on this page
use fictional data.*

[Workflows](#workflows) · [Get started](#get-started) · [Guides](#guides) · [Project status](#project-status)

## Workflows

### Update the budget

Edit the **`FY<year> Budget`** tab in Google Sheets. Preview your changes, then apply them.
The tool saves a backup first and leaves actual spending and other years alone.
If your editable tab has a different name, set `budget_tab_template` under `[sheets]` in
private `config.toml`, for example `"FY{fy} - Editable Internal Budget"`. The same commands
then use that tab; `{fy}` is replaced with the requested fiscal year.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/diagrams/budget-workflow-dark.svg">
  <img alt="Edit the annual budget, preview changes, update the Sheet with a backup, then prepare reports and comparisons." src="docs/diagrams/budget-workflow-light.svg">
</picture>

Reports read **Budget Timeseries**, the sheet's table of budget and actual amounts.
The [spreadsheet guide](docs/using-the-spreadsheet.md) explains which tabs to edit.

<details>
<summary><strong>Budget and report commands</strong></summary>

```powershell
uv run pta-finance sync-budget --fy 2027          # preview changes
uv run pta-finance sync-budget --fy 2027 --apply  # back up, then save
uv run pta-finance analyze --fy 2027             # show totals and comparisons
uv run pta-finance report --fy 2027 --variant both
```

The last command saves two HTML reports in `reports/output/` and records the run in the
sheet's `report_log`:

- **Internal:** totals, grade allocations, category comparisons, and source rows for the board.
- **Public:** summary figures, with payee, receipt, and individual source details omitted.

Reports cover the selected fiscal year's available data. Leave out `--fy` on `report` to use
the current fiscal year. The source rows are annual summaries, not an itemized bank ledger.

</details>

### Tell the financial story

A single slide brings together cash on hand, money raised, spending, and progress toward the
annual goals. The short summary explains why the balance changed.

![Fictional treasurer snapshot showing bank balances, fundraising, spending, budget progress, and a plain-language summary](docs/screenshots/treasurer-snapshot.png)

*Fictional copy of the approved treasurer snapshot prototype.
[Download the editable PowerPoint](docs/examples/treasurer-snapshot.pptx).
Automatic slide creation is still in development.*

### Work through reimbursements

Fetch receipt emails from Gmail, or use an existing email export. The tool sorts line items,
checks totals, and prepares the review queue.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/diagrams/reimbursement-workflow-dark.svg">
  <img alt="Collect receipt emails, organize the ledger and review queue, review each request, then draft a response or record a payment." src="docs/diagrams/reimbursement-workflow-light.svg">
</picture>

Each request shows its items, decision, payment status, and next step. New requests stay
**unreviewed** until a decision is recorded. Suggestions help with review; they do not authorize
payment. The treasurer sends replies and handles payments.

![Reimbursement request with item decisions, a question to resolve, and an email draft](docs/screenshots/reimbursement-detail.png)

*The items, open question, and draft reply stay together.*

Follow-up receipts and replies can be linked to the original request. Unclear matches remain
visible for review. If evidence behind an existing review changes or disappears, the refresh
stops so it can be checked.

Click an item in the queue to open its source receipt with a red outline around the matching
lines. Receipt pages and verified locations live in an optional private file beside the report;
items without one show **Receipt not linked**. See the
[receipt viewer guide](docs/receipt-viewer.md).

<details>
<summary><strong>Receipt and review commands</strong></summary>

These commands assume the setup in the [receipt guide](docs/loading-receipts.md) is complete,
including a category map and private review data file.

```powershell
# Download emails. Gmail access is read-only.
uv run pta-finance fetch-mail --since 2026-07-01

# Check the complete local archive before updating the Sheet.
uv run pta-finance ingest-receipts --source mail_samples --profile --originals-only
uv run pta-finance map-receipts --source mail_samples

# Optional: back up and replace the Reimbursements tab.
uv run pta-finance map-receipts --source mail_samples --write-tab Reimbursements

# Preview a review-queue refresh, then run it.
uv run pta-finance update-reimbursements --dry-run
uv run pta-finance update-reimbursements

# Rebuild the HTML from saved review data, without checking email.
uv run pta-finance report-reimbursements
```

The Sheet ledger and private review report are separate. Refreshing the report does not update
Sheets or send email. Add `--fetch-since` to `update-reimbursements` to fetch mail first.
Configure `[receipt_refresh]` to attach future receipt images and suggested red outlines during
updates; uncertain matches remain visibly review-needed. See [receipt setup](docs/receipt-viewer.md).
Both report commands also write `reports/output/reimbursement-queue-breakdown.copy.txt`,
with copyable six-line blocks for active Approved and Clarification item subtotals.
These labels follow the report recommendations; they do not record a payment approval.

</details>

### Produce the Main Report Set

One command builds five private reports from the same captured inputs: the reimbursement queue,
a reimbursement summary, a budget snapshot and a fundraising summary for the school year, and a
calendar-year CFO P&L summary. It reads the CFO workbook read-only, refreshes reimbursements as
`update-reimbursements` does, applies recorded adjustments, and publishes the new set only after
every report checks out. A failed run leaves the previous set in place.

Check first; the dry run validates everything and writes nothing:

```powershell
uv run pta-finance end-to-end-run --as-of 2030-08-15 --dry-run
```

Then build and publish:

```powershell
uv run pta-finance end-to-end-run --as-of 2030-08-15
```

Open `reports/output/main-report-set.html`. Setup, adjustments and recovery are in the
[Main Report Set guide](docs/main-report-set.md).

## Get started

Day-to-day budget editing happens in Google Sheets. Initial setup and report updates need
**Python 3.12+**, **[uv](https://docs.astral.sh/uv/)**, and Google credentials.

```powershell
git clone https://github.com/aberson/pta_finance.git
cd pta_finance
uv sync --locked --extra dev
Copy-Item config.example.toml config.toml
```

Follow **[SETUP.md](SETUP.md)** to connect your Sheet and fill in the private configuration.
Your organization name, contacts, fiscal year, and grade labels are configurable.
Gmail access is optional.

The toolkit expects a prepared spreadsheet. It does not build the budget tables or install
dashboards into a blank Sheet.

<details>
<summary><strong>Optional: monthly reports</strong></summary>

The [monthly workflow](.github/workflows/monthly-report.yml) refreshes both HTML reports on the
first of each month at 09:00 UTC. It can also be run manually. Setup uses the repository secrets
`GOOGLE_SA_KEY_B64` and `PTA_CONFIG_B64`. Mail fetching stays on your computer.

The workflow uploads **both reports**, including the internal version, as downloadable GitHub
files. Anyone signed in with repository read access can
[download them](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts).
For confidential data, use a private repository or change where the reports are delivered.
Private Drive upload is not built yet.

</details>

## Guides

| I want to… | Read |
|---|---|
| Edit the budget or understand the spreadsheet | [Spreadsheet guide](docs/using-the-spreadsheet.md) |
| Connect Google and run the tool | [Setup guide](SETUP.md) |
| Load receipts and refresh the review queue | [Receipt guide](docs/loading-receipts.md) |
| Check the receipt behind a queue item | [Receipt viewer guide](docs/receipt-viewer.md) |
| Build and publish the five-report Main Report Set | [Main Report Set guide](docs/main-report-set.md) |
| Ask an AI assistant for help | [Example prompts](docs/ask-an-ai-assistant.md) |

## Project status

**Ready to use:** budget updates, financial analysis, HTML reports, Gmail downloads, receipt
mapping, the reimbursement review queue, and click-to-view source receipts in that queue.
The reimbursement report prints linked and unlinked receipt counts. A claim with paid approved
lines and declined lines can close with both outcomes visible in its case history. The
`end-to-end-run` command builds and publishes the five-report Main Report Set, with each
summary laid out as a one-page board brief. It has run against the live workbooks; final
acceptance and the category crosswalk are still pending.

**Receipt autofill is partially built:** Steps38-40 delivered the browser gate repair, bounded image normalization and allowlisted fetcher. Step41 remains blocked on timing-risk disposition and a quiet-host full-suite gate; automatic end-to-end filling and attended acceptance remain pending. The [master plan](docs/plans/master_plan.md) records those boundaries. The Phase10 action queue is paused during Step51; its [resume handoff](docs/phase10-build-handoff.md) preserves the unfinished work.

**In progress:** turning the treasurer snapshot prototype into an automatic slide workflow.
The [slide plan](docs/plans/master_plan.md) tracks the remaining work.

**Optional collaboration proof:** the `web` extra adds an authenticated service for fixed
fictional requests, shared comments, and a reviewer-to-processor handoff. The reviewer approves
or does not approve; only the processor can complete an approved handoff. Completion does
not record a payment. Local checks use signed identities, real HTTP, Chromium, and Firestore
emulator transactions. Real two-account comments acceptance (M6) passed; hosted handoff
acceptance (M7) has passed. Opt-in `queue` mode adds six fixed fictional requests with independent
histories, current workflow counts, title/reference search, status/owner filters and direct detail
links. Reload or return to the queue to see shared changes. The queue build passed its tests,
independent reviews, and feature/main CI; its cloud image passed inspection. Hosted queue
acceptance (M8) remains pending. Ticket creation follows M8 and a separate engineering plan.
See the [delivery evidence](docs/shared-request-queue-sync.md) and [shared-workflow runbook](docs/shared-workflow-proof.md)
for startup, packaging, and the cloud acceptance procedures.

**Not built yet:** an admin web app, automatic reimbursement totals in the budget, or live
Drive receipt retrieval and report upload. Existing spreadsheet dashboards are specific to the
workbook. See the [project plan](docs/plans/master_plan.md) and
[known review limitations](docs/plans/master_plan.md) for details.

Real configuration, credentials, emails, and financial reports stay in private local files
excluded from Git. The tool does not require an AI model.

<details>
<summary><strong>For developers</strong></summary>

Python, pandas, and matplotlib handle the numbers and charts. Jinja2 renders the reports.
Google access uses `gspread` and Google's API client.

```powershell
uv sync --locked --extra dev --extra slides --extra web
uv run ruff check .
uv run ruff format --check .
uv run mypy --strict pta_finance
uv run pytest -q
uv run python scripts/check_no_identity.py
```

Native PDF parser tests need Windows and the `slides` extra.
Full-package mypy and the complete web-enabled suite require `web`; start the loopback
Firestore emulator and install Chromium as described in the shared-workflow runbook first.
The base installation can still run its existing regression suite without `web`.
See [CI](.github/workflows/ci.yml) for the Linux test split.

</details>

<details>
<summary><strong>Update the README visuals</strong></summary>

Capture the two reimbursement screenshots with fictional data:

```powershell
uv run --with playwright==1.58.0 python -m playwright install chromium
uv run --with playwright==1.58.0 python scripts/capture_readme.py
```

The [capture script](scripts/capture_readme.py) renders the real report template without reading
private data or connecting to Google.

The [snapshot source](docs/examples/treasurer-snapshot.pptx) is an editable, fictional slide.
After editing it, export its screenshot with desktop PowerPoint on Windows:

```powershell
powershell -NoProfile -File scripts/export_example_snapshot.ps1
```

Workflow diagrams are editable SVGs in [docs/diagrams](docs/diagrams/), with light and dark
versions in the style of [skill-mesh](https://github.com/aberson/skill-mesh).

</details>

## License

[MIT](LICENSE).
