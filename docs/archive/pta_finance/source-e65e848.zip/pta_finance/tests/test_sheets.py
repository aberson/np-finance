"""Tests for pta_finance.sheets — mocked gspread, NO live Google calls.

The headline test exercises the **production** ``SheetsClient.upsert_rows`` path (not a
parallel helper) and asserts (a) a single row-targeted ``batch_update`` and (b) the
429-then-success backoff retry through ``_with_retry`` (with an injected no-op sleep).
"""

from __future__ import annotations

from typing import Any

import pytest
from gspread.exceptions import APIError
from gspread.utils import ValueInputOption, rowcol_to_a1

from pta_finance import schema
from pta_finance import sheets as sheets_module
from pta_finance.config import Config
from pta_finance.sheets import SchemaError, SheetsClient
from tests.conftest import (
    FakeClient,
    FakeSpreadsheet,
    FakeWorksheet,
    JournalWorksheet,
    RecordingSleep,
    make_api_error,
)

_TXN = schema.TAB_TRANSACTIONS
_COLS = schema.TRANSACTIONS_COLUMNS


def _client(config: Config, worksheet: FakeWorksheet, **kwargs: object) -> SheetsClient:
    """Build a SheetsClient wired to a single-tab fake spreadsheet (no network)."""
    spreadsheet = FakeSpreadsheet({_TXN: worksheet})
    fake_client = FakeClient(spreadsheet)
    return SheetsClient(config, gspread_client=fake_client, **kwargs)  # type: ignore[arg-type]


def _header_row() -> list[str]:
    return list(_COLS)


def _row_for(txn_id: str) -> dict[str, str]:
    row = {col: "" for col in _COLS}
    row["id"] = txn_id
    row["payee"] = "Example Vendor"
    return row


# --- Integration test through the production caller -------------------------


def test_replace_tab_grid_creates_then_writes_amount_numeric(fake_config: Config) -> None:
    """replace_tab_grid adds an absent machine-owned tab, writes the whole grid RAW, then
    re-writes the amount column USER_ENTERED so it totals in the Sheet's native SUM/QUERY."""
    spreadsheet = FakeSpreadsheet({})  # no tabs yet
    client = SheetsClient(fake_config, gspread_client=FakeClient(spreadsheet))  # type: ignore[arg-type]

    status = client.replace_tab_grid(
        "Reimbursements",
        ["message_id", "amount", "month"],
        [["<a@x>", "10.00", "2026-06"], ["<b@x>", "20.50", "2026-05"]],
        numeric_columns=["amount"],
    )

    assert status == "created"
    assert [t for (t, _r, _c) in spreadsheet.add_worksheet_calls] == ["Reimbursements"]

    ws = spreadsheet.worksheet("Reimbursements")
    # Two update passes: the full grid RAW, then just the amount column USER_ENTERED.
    assert len(ws.update_calls) == 2
    grid_range, grid_values = ws.update_calls[0]
    assert grid_range == "A1:C3"
    assert grid_values[0] == ["message_id", "amount", "month"]
    assert ws.update_vios[0] == ValueInputOption.raw
    amount_range, amount_values = ws.update_calls[1]
    assert amount_range == "B2:B3"  # amount is column B, data rows 2..3
    assert amount_values == [["10.00"], ["20.50"]]
    assert ws.update_vios[1] == ValueInputOption.user_entered


def test_upsert_rows_issues_single_row_targeted_batch_update(fake_config: Config) -> None:
    """upsert_rows updates an existing id in place and appends a new id — one batch_update,
    each request a single-row A1 range, NOT a full-sheet write."""
    # Grid: header + one existing row (TXN-FY26-0001 at sheet row 2).
    grid = [_header_row(), [_row_for("TXN-FY26-0001")[c] for c in _COLS]]
    ws = FakeWorksheet(grid)
    sleep = RecordingSleep()
    client = _client(fake_config, ws, sleep=sleep)

    client.upsert_rows(
        _TXN,
        {
            "TXN-FY26-0001": _row_for("TXN-FY26-0001"),  # existing -> update row 2
            "TXN-FY26-0002": _row_for("TXN-FY26-0002"),  # new -> append at row 3
        },
    )

    # Exactly ONE atomic batch_update was issued (all-or-nothing write).
    assert len(ws.batch_update_calls) == 1
    requests = ws.batch_update_calls[0]
    assert len(requests) == 2

    ranges = [req["range"] for req in requests]
    ncols = len(_COLS)  # 15 -> column O
    # Existing id updates ONLY its own row (row 2); new id targets the appended row 3.
    assert "A2:O2" in ranges  # literal asserts the row-targeted range, not a full-sheet write
    assert "A3:O3" in ranges
    # Each request writes exactly one row of exactly ncols values — never the whole tab.
    for req in requests:
        assert len(req["values"]) == 1
        assert len(req["values"][0]) == ncols
    # No append_rows was used (upsert batches everything atomically).
    assert ws.append_rows_calls == []
    # Happy path: no retries, so sleep was never called here.
    assert sleep.calls == []


def test_upsert_rows_retries_on_429_then_succeeds(fake_config: Config) -> None:
    """A 429 APIError on the first batch_update is retried via _with_retry; the second
    call succeeds. The injected sleep proves the backoff path ran (instantly)."""
    grid = [_header_row()]
    ws = FakeWorksheet(grid, fail_first={"batch_update": [make_api_error(429)]})
    sleep = RecordingSleep()
    client = _client(fake_config, ws, sleep=sleep, max_retries=5)

    client.upsert_rows(_TXN, {"TXN-FY26-0001": _row_for("TXN-FY26-0001")})

    # batch_update was attempted twice (429 then success) and ultimately committed once.
    assert len(ws.batch_update_calls) == 1
    # The backoff slept exactly once (one retryable failure).
    assert len(sleep.calls) == 1
    assert sleep.calls[0] > 0  # base_delay * 2**1 + jitter > 0
    # The committed batch carries the appended row's value.
    committed = ws.batch_update_calls[0]
    assert committed[0]["values"][0][0] == "TXN-FY26-0001"


def test_with_retry_reraises_after_max_attempts(fake_config: Config) -> None:
    """Persistent 429s exhaust max_retries and re-raise the APIError."""
    # 4 leading failures with max_retries=5 -> attempts 1..4 retry, attempt 5 re-raises.
    failures = [make_api_error(429) for _ in range(5)]
    ws = FakeWorksheet([_header_row()], fail_first={"batch_update": failures})
    sleep = RecordingSleep()
    client = _client(fake_config, ws, sleep=sleep, max_retries=5)

    with pytest.raises(APIError):
        client.upsert_rows(_TXN, {"TXN-FY26-0001": _row_for("TXN-FY26-0001")})
    # Slept on attempts 1..4 (4 retries), then re-raised on attempt 5.
    assert len(sleep.calls) == 4


def test_non_retryable_apierror_propagates_without_retry(fake_config: Config) -> None:
    """A 404 APIError is NOT retried — it propagates on the first failure, no sleep."""
    ws = FakeWorksheet([_header_row()], fail_first={"batch_update": [make_api_error(404)]})
    sleep = RecordingSleep()
    client = _client(fake_config, ws, sleep=sleep)

    with pytest.raises(APIError):
        client.upsert_rows(_TXN, {"TXN-FY26-0001": _row_for("TXN-FY26-0001")})
    assert sleep.calls == []


# --- validate_schema --------------------------------------------------------


def test_validate_schema_passes_on_matching_header(fake_config: Config) -> None:
    ws = FakeWorksheet([_header_row()])
    client = _client(fake_config, ws)
    client.validate_schema(_TXN)  # no raise


def test_validate_schema_raises_on_mismatched_header(fake_config: Config) -> None:
    bad_header = ["id", "WRONG", *list(_COLS[2:])]
    ws = FakeWorksheet([bad_header])
    client = _client(fake_config, ws)

    with pytest.raises(SchemaError) as exc_info:
        client.validate_schema(_TXN)
    err = exc_info.value
    assert err.tab == _TXN
    assert err.expected == _COLS
    assert err.actual == tuple(bad_header)


# --- read_tab ---------------------------------------------------------------


def test_read_tab_returns_dicts_keyed_by_schema_columns(fake_config: Config) -> None:
    row = _row_for("TXN-FY26-0001")
    grid = [_header_row(), [row[c] for c in _COLS]]
    ws = FakeWorksheet(grid)
    client = _client(fake_config, ws)

    records = client.read_tab(_TXN)

    assert len(records) == 1
    assert set(records[0]) == set(_COLS)
    assert records[0]["id"] == "TXN-FY26-0001"
    assert records[0]["payee"] == "Example Vendor"


def test_read_values_returns_raw_grid_coerced_to_str(fake_config: Config) -> None:
    """read_values returns the RAW grid (header row included) with every cell coerced to str —
    no header-keyed dicts, unlike read_tab. Used by import-budget on a non-canonical tab."""
    grid = [
        ["", "Type", "Line Item", "Proposed"],  # a non-row-1 header, leading junk column
        ["", "Income", "Membership", 1500],  # an int cell -> "1500"
    ]
    ws = FakeWorksheet(grid)
    client = _client(fake_config, ws)

    values = client.read_values(_TXN)

    assert values == [
        ["", "Type", "Line Item", "Proposed"],
        ["", "Income", "Membership", "1500"],
    ]


def test_snapshot_values_read_tagged_user_entered_values_for_only_requested_tab(
    fake_config: Config,
) -> None:
    formatted_grid = [
        ["formula", "literal", "number", "boolean", "date", "empty"],
        ["3", "=1+2", "$12.50", "TRUE", "1/2/2030", ""],
    ]
    tagged_grid = [
        [{"userEnteredValue": {"stringValue": value}} for value in formatted_grid[0]],
        [
            {"userEnteredValue": {"formulaValue": "=1+2"}},
            {"userEnteredValue": {"stringValue": "=1+2"}},
            {"userEnteredValue": {"numberValue": 12.5}},
            {"userEnteredValue": {"boolValue": True}},
            {"userEnteredValue": {"numberValue": 47485}},
            {"userEnteredValue": None},
        ],
    ]

    class MetadataSpreadsheet(FakeSpreadsheet):
        def __init__(self) -> None:
            super().__init__({_TXN: FakeWorksheet(formatted_grid)})
            self.metadata_params: list[dict[str, object]] = []

        def fetch_sheet_metadata(self, params: dict[str, object]) -> dict[str, object]:
            self.metadata_params.append(dict(params))
            return {"sheets": [{"data": [{"rowData": [{"values": row} for row in tagged_grid]}]}]}

    spreadsheet = MetadataSpreadsheet()
    client = SheetsClient(fake_config, gspread_client=FakeClient(spreadsheet))  # type: ignore[arg-type]

    assert client.read_values(_TXN) == formatted_grid
    assert client.read_snapshot_values(_TXN) == tagged_grid
    assert spreadsheet.metadata_params == [
        {
            "includeGridData": True,
            "ranges": "'transactions'",
            "fields": "sheets.data.rowData.values.userEnteredValue",
        }
    ]


def test_append_rows_writes_in_schema_order(fake_config: Config) -> None:
    ws = FakeWorksheet([_header_row()])
    client = _client(fake_config, ws)

    client.append_rows(_TXN, [_row_for("TXN-FY26-0003")])

    assert len(ws.append_rows_calls) == 1
    appended = ws.append_rows_calls[0][0]
    assert appended[0] == "TXN-FY26-0003"  # id is column 0 in schema order
    assert len(appended) == len(_COLS)


def test_delete_rows_by_id_targets_only_matching_rows(fake_config: Config) -> None:
    grid = [
        _header_row(),
        [_row_for("TXN-FY26-0001")[c] for c in _COLS],
        [_row_for("TXN-FY26-0002")[c] for c in _COLS],
    ]
    ws = FakeWorksheet(grid)
    client = _client(fake_config, ws)

    client.delete_rows_by_id(_TXN, ["TXN-FY26-0002"])

    # Only the second data row (sheet row 3) was deleted.
    assert ws.delete_rows_calls == [3]
    remaining_ids = [r[0] for r in ws.grid[1:]]
    assert remaining_ids == ["TXN-FY26-0001"]


# --- Regression: the header row (row 1) is never a data-write target ---------


def test_upsert_never_targets_header_row(fake_config: Config) -> None:
    """Regression: the header (row 1) is never treated as a data row — an id equal to a
    column name cannot clobber it, and a header-only sheet appends at row 2 (not row 1)."""
    ws = FakeWorksheet([_header_row()])  # header only, no data rows
    client = _client(fake_config, ws)

    client.upsert_rows(
        _TXN,
        {
            "TXN-FY26-0009": _row_for("TXN-FY26-0009"),  # normal new id
            "id": _row_for("id"),  # pathological id == the header value
        },
    )

    ranges = {req["range"] for req in ws.batch_update_calls[0]}
    assert "A1:O1" not in ranges  # header row never written
    assert ranges == {"A2:O2", "A3:O3"}  # both new rows land at/after row 2


def test_delete_does_not_remove_header_row(fake_config: Config) -> None:
    """Regression: deleting an id equal to the header value must not delete the header."""
    grid = [_header_row(), [_row_for("TXN-FY26-0001")[c] for c in _COLS]]
    ws = FakeWorksheet(grid)
    client = _client(fake_config, ws)

    client.delete_rows_by_id(_TXN, ["id"])  # "id" is the header value in row 1

    assert ws.delete_rows_calls == []  # header (row 1) not deleted
    assert ws.grid[0] == _header_row()  # header intact


def test_update_rows_by_index_targets_only_given_rows(fake_config: Config) -> None:
    """update_rows_by_index writes ONLY the given 1-based rows, one A1 range each, one batch."""
    grid = [_header_row(), [_row_for("TXN-FY26-0001")[c] for c in _COLS]]
    ws = FakeWorksheet(grid)
    client = _client(fake_config, ws)

    flagged = _row_for("")  # a malformed, id-less row
    flagged["needs_review"] = "TRUE"
    client.update_rows_by_index(_TXN, {2: flagged})

    assert len(ws.batch_update_calls) == 1
    ranges = {req["range"] for req in ws.batch_update_calls[0]}
    assert ranges == {"A2:O2"}  # row-targeted, never the whole tab


def test_update_rows_by_index_rejects_header_row(fake_config: Config) -> None:
    """Writing sheet row 1 (the header) is refused — a guard against clobbering the header."""
    ws = FakeWorksheet([_header_row()])
    client = _client(fake_config, ws)
    with pytest.raises(ValueError):
        client.update_rows_by_index(_TXN, {1: _row_for("X")})


# --- ensure_tab / list_worksheet_titles (init-sheet bootstrap) --------------


def _multi_client(
    config: Config, worksheets: dict[str, FakeWorksheet]
) -> tuple[SheetsClient, FakeSpreadsheet]:
    """Build a SheetsClient over a multi-tab fake spreadsheet, returning both for asserts."""
    spreadsheet = FakeSpreadsheet(worksheets)
    fake_client = FakeClient(spreadsheet)
    client = SheetsClient(config, gspread_client=fake_client)  # type: ignore[arg-type]
    return client, spreadsheet


def test_list_worksheet_titles_returns_all_tab_names(fake_config: Config) -> None:
    client, _ = _multi_client(
        fake_config,
        {_TXN: FakeWorksheet([_header_row()]), schema.TAB_BUDGET: FakeWorksheet([])},
    )
    assert client.list_worksheet_titles() == [_TXN, schema.TAB_BUDGET]


def test_ensure_tab_creates_missing_worksheet_with_schema_headers(fake_config: Config) -> None:
    """A missing tab is added (sized to the schema) and row 1 gets the EXACT schema headers."""
    # Spreadsheet starts with an unrelated tab; the target tab is absent.
    client, spreadsheet = _multi_client(fake_config, {"unrelated": FakeWorksheet([])})

    status = client.ensure_tab(_TXN)

    assert status == "created"
    # add_worksheet was called once, sized to len(columns).
    assert spreadsheet.add_worksheet_calls == [(_TXN, 100, len(_COLS))]
    created = spreadsheet.worksheet(_TXN)
    # The header row written equals list(schema.TABS[tab]) exactly.
    assert len(created.update_calls) == 1
    _range, values = created.update_calls[0]
    assert values == [list(schema.TABS[_TXN])]
    assert created.grid[0] == list(_COLS)


def test_ensure_tab_idempotent_on_correct_tab_issues_no_write(fake_config: Config) -> None:
    """Re-running on an already-correct tab returns 'ok' and issues NO write."""
    ws = FakeWorksheet([_header_row()])
    client, spreadsheet = _multi_client(fake_config, {_TXN: ws})

    status = client.ensure_tab(_TXN)

    assert status == "ok"
    assert ws.update_calls == []  # no write
    assert ws.batch_update_calls == []
    assert spreadsheet.add_worksheet_calls == []


def test_ensure_tab_writes_headers_when_row1_empty(fake_config: Config) -> None:
    """An existing tab whose row 1 is empty gets its header written, returning 'headers-written'."""
    ws = FakeWorksheet([])  # exists but completely empty (no header)
    client, spreadsheet = _multi_client(fake_config, {_TXN: ws})

    status = client.ensure_tab(_TXN)

    assert status == "headers-written"
    assert spreadsheet.add_worksheet_calls == []  # not created — already existed
    assert len(ws.update_calls) == 1
    _range, values = ws.update_calls[0]
    assert values == [list(schema.TABS[_TXN])]
    assert ws.grid[0] == list(_COLS)


def test_ensure_tab_raises_on_nonempty_mismatch_without_clobber(fake_config: Config) -> None:
    """A non-empty, wrong-shaped header raises SchemaError and issues NO write (no clobber)."""
    bad_header = ["id", "WRONG", *list(_COLS[2:])]
    ws = FakeWorksheet([bad_header])
    client, _ = _multi_client(fake_config, {_TXN: ws})

    with pytest.raises(SchemaError) as exc_info:
        client.ensure_tab(_TXN)

    err = exc_info.value
    assert err.tab == _TXN
    assert err.expected == _COLS
    assert err.actual == tuple(bad_header)
    # No write of any kind — the real (but wrong-shaped) data is preserved.
    assert ws.update_calls == []
    assert ws.batch_update_calls == []
    assert ws.grid == [bad_header]


def test_ensure_tab_recovers_from_duplicate_title_after_retried_create(
    fake_config: Config,
) -> None:
    """A retried create that already applied server-side raises a 400 duplicate-title error;
    ensure_tab must NOT abort — it falls through, finds the tab present with an empty row 1,
    writes the schema header, and returns a sensible status (not propagate the APIError)."""
    dup_err = make_api_error(
        400,
        message='A sheet with the name "transactions" already exists.',
        api_status="INVALID_ARGUMENT",
    )
    # The target tab is absent initially; add_worksheet applies the create (server-side)
    # then raises the duplicate-title 400 — exactly the retry hazard.
    spreadsheet = FakeSpreadsheet({"unrelated": FakeWorksheet([])}, add_worksheet_error=dup_err)
    fake_client = FakeClient(spreadsheet)
    client = SheetsClient(fake_config, gspread_client=fake_client)  # type: ignore[arg-type]

    status = client.ensure_tab(_TXN)

    # Recovered: the create applied, row 1 was empty, so the header was written.
    assert status == "headers-written"
    created = spreadsheet.worksheet(_TXN)
    assert len(created.update_calls) == 1
    _range, values = created.update_calls[0]
    assert values == [list(schema.TABS[_TXN])]
    assert created.grid[0] == list(_COLS)


def test_ensure_tab_propagates_non_duplicate_400(fake_config: Config) -> None:
    """A 400 that is NOT a duplicate-title error still propagates (no silent swallow)."""
    other_err = make_api_error(
        400, message="Invalid requests[0].addSheet: bad grid", api_status="INVALID_ARGUMENT"
    )
    spreadsheet = FakeSpreadsheet({"unrelated": FakeWorksheet([])}, add_worksheet_error=other_err)
    fake_client = FakeClient(spreadsheet)
    client = SheetsClient(fake_config, gspread_client=fake_client)  # type: ignore[arg-type]

    with pytest.raises(APIError):
        client.ensure_tab(_TXN)


# --- schema-independent writes (Budget Timeseries reconcile) ----------------


def test_update_cells_writes_user_entered(fake_config: Config) -> None:
    """update_cells writes USER_ENTERED so a numeric amount string lands as a NUMBER — the
    operator tab's native SUM/QUERY formulas skip a text cell (regression: RAW stored '10000'
    as text and Group Explorer under-counted it)."""
    ws = FakeWorksheet([["fiscal_year", "amount"]])
    client = _client(fake_config, ws)

    client.update_cells(_TXN, {"E246": "10000", "N246": "a note"})

    assert ws.batch_update_vios == ["USER_ENTERED"]
    (requests,) = ws.batch_update_calls
    ranges = {r["range"]: r["values"][0][0] for r in requests}
    assert ranges == {"E246": "10000", "N246": "a note"}


def test_update_cells_noop_when_empty(fake_config: Config) -> None:
    ws = FakeWorksheet([["a"]])
    client = _client(fake_config, ws)
    client.update_cells(_TXN, {})
    assert ws.batch_update_calls == []


def test_append_raw_rows_writes_user_entered(fake_config: Config) -> None:
    """append_raw_rows writes USER_ENTERED so an appended amount is a number, not text."""
    ws = FakeWorksheet([["fiscal_year", "amount"]])
    client = _client(fake_config, ws)

    client.append_raw_rows(_TXN, [["2027", "500"]])

    assert ws.append_rows_vios == ["USER_ENTERED"]
    assert ws.append_rows_calls == [[["2027", "500"]]]


def test_append_raw_rows_noop_when_empty(fake_config: Config) -> None:
    ws = FakeWorksheet([["a"]])
    client = _client(fake_config, ws)
    client.append_raw_rows(_TXN, [])
    assert ws.append_rows_calls == []


def test_spreadsheet_id_names_the_opened_workbook(fake_config: Config) -> None:
    assert SheetsClient(fake_config).spreadsheet_id == "fake-spreadsheet-id"
    other = SheetsClient(fake_config, spreadsheet_id="fake-other-id")
    assert other.spreadsheet_id == "fake-other-id"


def test_write_raw_ranges_is_one_raw_batch_of_exact_ranges(fake_config: Config) -> None:
    """RAW keeps formula-like text as text and never coerces dates or amounts."""
    ws = JournalWorksheet([["a"]], sheet_id=1)
    client = _client(fake_config, ws)

    client.write_raw_ranges(_TXN, {"A5": [["=SUM(A1)"]], "A6:B6": [["2030-01-15", "-3.00"]]})

    assert ws.batch_update_vios == [ValueInputOption.raw]
    (requests,) = ws.batch_update_calls
    assert requests == [
        {"range": "A5", "values": [["=SUM(A1)"]]},
        {"range": "A6:B6", "values": [["2030-01-15", "-3.00"]]},
    ]
    assert ws.tagged_grid()[4][0] == {"userEnteredValue": {"stringValue": "=SUM(A1)"}}


def test_write_raw_ranges_noop_when_empty(fake_config: Config) -> None:
    ws = FakeWorksheet([["a"]])
    client = _client(fake_config, ws)
    client.write_raw_ranges(_TXN, {})
    assert ws.batch_update_calls == []


def test_ensure_grid_size_only_appends_what_is_missing(fake_config: Config) -> None:
    ws = JournalWorksheet([["a"]], sheet_id=1, row_count=10, col_count=5)
    client = _client(fake_config, ws)

    assert client.ensure_grid_size(_TXN, 8, 5) == (0, 0)
    assert ws.add_rows_calls == [] and ws.add_cols_calls == []
    assert client.ensure_grid_size(_TXN, 14, 12) == (4, 7)
    assert ws.add_rows_calls == [4] and ws.add_cols_calls == [7]
    assert (ws.row_count, ws.col_count) == (14, 12)
    assert ws.grid == [["a"]]


class _PrefixingWorksheet(FakeWorksheet):
    """Mutates each request's range in place, as gspread's batch_update does, then 429s once."""

    def __init__(self) -> None:
        super().__init__([["a"]], title="Tab")
        self.seen: list[list[str]] = []
        self.failures = 1

    def batch_update(self, data: Any, value_input_option: str | None = None) -> dict[str, Any]:
        self.seen.append([request["range"] for request in data])
        for request in data:
            request["range"] = f"'Tab'!{request['range']}"
        if self.failures:
            self.failures -= 1
            raise make_api_error(429)
        return super().batch_update(data, value_input_option)


@pytest.mark.parametrize(
    "method", ["write_raw_ranges", "update_cells", "upsert_rows", "update_rows_by_index"]
)
def test_retried_batch_writes_resend_the_original_ranges(fake_config: Config, method: str) -> None:
    ws = _PrefixingWorksheet()
    client = _client(fake_config, ws, sleep=RecordingSleep())

    if method == "write_raw_ranges":
        client.write_raw_ranges(_TXN, {"A5": [["x"]]})
        expected = "A5"
    elif method == "update_cells":
        client.update_cells(_TXN, {"E7": "1"})
        expected = "E7"
    elif method == "upsert_rows":
        client.upsert_rows(_TXN, {"TXN-1": _row_for("TXN-1")})
        expected = f"A2:{rowcol_to_a1(2, len(_COLS))}"
    else:
        client.update_rows_by_index(_TXN, {2: _row_for("TXN-1")})
        expected = f"A2:{rowcol_to_a1(2, len(_COLS))}"

    assert ws.seen == [[expected], [expected]]


def test_ensure_grid_size_never_shrinks_a_wider_or_taller_tab(fake_config: Config) -> None:
    """The common case: a default 26-column tab and a 12-column journal."""
    ws = JournalWorksheet([["a"]], sheet_id=1, row_count=1000, col_count=26)
    client = _client(fake_config, ws)

    assert client.ensure_grid_size(_TXN, 20, 12) == (0, 0)
    assert ws.add_rows_calls == [] and ws.add_cols_calls == []
    assert (ws.row_count, ws.col_count) == (1000, 26)


@pytest.mark.parametrize("status", [429, 500, 503])
def test_write_raw_ranges_without_retry_sends_exactly_once(
    fake_config: Config, status: int
) -> None:
    """A caller that owns its retries sees the first retryable failure itself."""
    ws = FakeWorksheet([["a"]], fail_first={"batch_update": [make_api_error(status)]})
    sleep = RecordingSleep()
    client = _client(fake_config, ws, sleep=sleep)

    with pytest.raises(APIError):
        client.write_raw_ranges(_TXN, {"A5": [["x"]]}, retry=False)
    assert ws.batch_update_calls == [] and sleep.calls == []

    ws._fail_first["batch_update"] = [make_api_error(status)]
    client.write_raw_ranges(_TXN, {"A5": [["x"]]})  # the default still retries for others
    assert len(ws.batch_update_calls) == 1 and len(sleep.calls) == 1


def test_backoff_delay_doubles_adds_the_jitter_draw_and_stops_at_the_cap(
    fake_config: Config, monkeypatch: pytest.MonkeyPatch
) -> None:
    draws: list[tuple[float, float]] = []

    def draw(low: float, high: float) -> float:
        draws.append((low, high))
        return 0.375  # a non-zero jitter draw

    monkeypatch.setattr(sheets_module.random, "uniform", draw)
    client = _client(fake_config, FakeWorksheet([]), base_delay=1.0, jitter=0.5, max_retries=3)
    assert [client.backoff_delay(n) for n in (1, 2, 3)] == [2.375, 4.375, None]
    assert draws == [(0, 0.5), (0, 0.5)]


def test_transient_statuses_and_http_status_have_one_owner() -> None:
    assert [sheets_module.is_transient_status(s) for s in (429, 500, 503)] == [True] * 3
    assert not sheets_module.is_transient_status(None)
    assert not sheets_module.is_transient_status(502)

    class _CodedError(Exception):
        code = 503  # no response object: the parsed error code is used

    assert sheets_module.http_status(make_api_error(429)) == 429
    assert sheets_module.http_status(_CodedError()) == 503
    assert sheets_module.http_status(ConnectionError("lost")) is None


def test_http_status_prefers_the_response_status_over_the_parsed_code() -> None:
    error = make_api_error(503)
    error.code = 429  # the parsed JSON code disagrees with the HTTP response
    assert sheets_module.http_status(error) == 503


def test_http_status_ignores_a_non_integer_code() -> None:
    class _TextCodedError(Exception):
        code = "503"  # not an int: never trusted as a status

    assert sheets_module.http_status(_TextCodedError()) is None
